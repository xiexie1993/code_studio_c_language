/***
*execve.c - execute a file with a given environment
*
*       Copyright (c) 1985-1997, Microsoft Corporation. All rights reserved.
*
*Purpose:
*       defines _execve() - execute a file
*
*******************************************************************************/

#define EXECVE

#include "spawnve.c"
