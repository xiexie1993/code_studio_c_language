/***
*cprintf.c - Conio version of printf
*
*       Copyright (c) 1991-1997, Microsoft Corporation.  All rights reserved.
*
*Purpose:
*       Perform formatted i/o directly to the console.
*
*******************************************************************************/

#define CPRFLAG 1
#include "output.c"
