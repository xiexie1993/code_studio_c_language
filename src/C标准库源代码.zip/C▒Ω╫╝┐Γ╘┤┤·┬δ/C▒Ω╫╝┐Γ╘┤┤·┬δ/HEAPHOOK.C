/***
*heaphook.c - set the heap hook
*
*       Copyright (c) 1995-1997, Microsoft Corporation. All rights reserved.
*
*Purpose:
*       Defines the following functions:
*           _setheaphook() - set the heap hook
*
*******************************************************************************/

